﻿using Common.CommonErrors;
using Domain.Contracts.Repositories;
using Domain.Models;
using Infrastructure.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Controllers
{
    [ApiController]
    [Route("v1")]
    public class AgendaController : ControllerBase, IDisposable
    {
        private readonly IContactRepository _service;

        public AgendaController(IContactRepository service)
        {
            _service = service;
        }
        [HttpGet]
        [Route("")]
        public async Task<ActionResult<List<Contact>>> Get([FromServices] AppDataContext context)
        {
            try
            {
                var contacts = await context.Contacts.ToListAsync();
                return contacts;
            }
            catch (Exception)
            {
                throw ErrorSpam.NotFound();
            }
        }
        [HttpPost]
        [Route("Add")]
        public async Task<ActionResult<Contact>> Post(
            [FromServices] AppDataContext context,
            [FromBody] Contact model)
        {
            if (ModelState.IsValid)
            {
                if (context.Contacts.Where(x => x.Name == model.Name)
                    .FirstOrDefault() == null)
                {
                    context.Contacts.Add(model);
                    await context.SaveChangesAsync();
                    return model;
                }
                else
                    return BadRequest(ModelState);
            }
            else
                return BadRequest(ModelState);
        }
        //[HttpPost]
        //[Route("add")]
        //public void PostContacts(string name, string emai, string address, string phone)
        //{
        //    try
        //    {
        //        _service.Create(name, emai, address, phone);
        //    }
        //    catch (Exception)
        //    {

        //        throw ErrorSpam.CannotSave();
        //    }
        //}
        [HttpDelete]
        [Route("erase")]
        public async Task<ActionResult<Contact>> Delete(
            [FromServices] AppDataContext context,
            [FromBody] string model)
        {
            if (ModelState.IsValid)
            {
                var contt = context.Contacts.Where(x => x.Name == model)
                    .FirstOrDefault();
                if (contt != null)
                {
                    context.Contacts.Remove(contt);
                    await context.SaveChangesAsync();
                    return contt;
                }
                else
                    return BadRequest(ModelState);
            }
            else
                return BadRequest(ModelState);
        }
        //[HttpDelete]
        //[Route("erase")]
        //public void DeleteContact(string name)
        //{         
        //    try
        //    {
        //        _service.Delete(name);
        //    }
        //    catch (Exception)
        //    {

        //        throw ErrorSpam.NotFound();
        //    }
        //}
        public void Dispose()
        {
            _service.Dispose();
        }
    }
}

﻿using Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infrastructure.Data.Map
{
    class AgendaMap : IEntityTypeConfiguration<Contact>
    {
        public void Configure(EntityTypeBuilder<Contact> builder)
        {
            //base.OnModelCreating(modelBuilder);
            builder.ToTable("AgendaDB");
            //setando os elementos da tabela
            builder.Property(x => x.Id)
                .UseIdentityColumn();
            builder.Property(x => x.Name)
                .HasMaxLength(60)
                .IsRequired();
            builder.Property(x => x.Email)
                .HasMaxLength(160)
                .IsRequired();
            builder.Property(x => x.Phone)
                .HasMaxLength(11)
                .IsRequired();
            builder.Property(x => x.Address)
                .HasMaxLength(160)
                .IsRequired();
        }
    }
}

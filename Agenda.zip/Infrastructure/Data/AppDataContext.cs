﻿using Domain.Models;
using Infrastructure.Data.Map;
using Microsoft.EntityFrameworkCore;
using System.Linq;


namespace Infrastructure.Data
{
    public class AppDataContext : DbContext
    {
        //private readonly string dbPath = "Integrated Security=SSPI;Persist Security Info=False;" +
        //        "Initial Catalog=AgendaDB;Data Source=DESKTOP-NDC7M6O\\SQLEXPRESS02";

        public AppDataContext(DbContextOptions<AppDataContext> options) : base(options)
        {
            
        }
        //tabela Contatos
        public DbSet<Contact> Contacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AgendaMap());
        }
        
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    //optionsBuilder.UseSqlServer(dbPath);
        //}
    }
}

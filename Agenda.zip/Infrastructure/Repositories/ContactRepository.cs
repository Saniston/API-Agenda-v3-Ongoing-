﻿using Common.CommonErrors;
using Domain.Contracts.Repositories;
using Domain.Models;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private readonly AppDataContext _context;

        public ContactRepository(AppDataContext context)
        {
            _context = context;
        }

        public Contact Get(string name)
        {
            var ctt = _context.Contacts
                    .Where(x => x.Name == name).FirstOrDefault();
            if(ctt == null)
                throw ErrorSpam.InvalidName();
            return ctt;
        }

        public Contact Get(int id)
        {
            var ctt = _context.Contacts
                .Where(x => x.Id == id).FirstOrDefault();
            if (ctt == null)
                throw ErrorSpam.InvalidName();
            return ctt;
        }

        public IEnumerable<Contact> GetAllContacts()
        {
            return _context.Contacts.AsNoTracking().ToList();
        }

        //public List<Contact> GetAllContacts()
        //{
        //    var ctts = new List<Contact>();
        //    _context.Contacts.ForEachAsync(c => ctts.Add(
        //        new Contact(c.Name, c.Email, c.Address, c.Phone)));
        //    if (ctts == null)
        //        throw ErrorSpam.NotFound();
        //    return ctts;
        //}

        public void Create(string name, string email, string address, string phone)
        {
            if (Get(name) != null)
                throw ErrorSpam.InvalidName();
;           _context.Contacts.Add(new Contact(name, email, address, phone));
            _context.SaveChanges();
        }

        public void Delete(string name)
        {
            var contact = Get(name);
            if (contact == null)
                throw ErrorSpam.NotFound();
            _context.Contacts.Remove(contact);
            _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }

        public void Update(Contact contact)
        {
            _context.Entry(contact).State = EntityState.Modified;
            _context.SaveChanges();
        }
    }
}

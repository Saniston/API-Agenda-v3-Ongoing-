﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Common.Validations
{
    public abstract class Validation
    {
        /// <summary>
        /// Remove caracteres especiais e letras da string
        /// </summary>
        /// <param name="target">string alvo a remover todos caracteres não numéricos</param>
        /// <returns></returns>
        static protected string RemoveNonNumeric(string target)
        {
            return Regex.Replace(target, @"[^0-9]+", "");
        }

        /// <summary>
        /// Compara se a string está dentro do tamanho especificado
        /// </summary>
        /// <param name="target">string alvo</param>
        /// <param name="min">valor mínimo</param>
        /// <param name="max">valor máximo</param>
        /// <returns></returns>
        static protected bool StringExceedsOrLeft(string target, int min, int max)
        {
            if (target.Length < min || target.Length > max)
                return true;
            return false;
        }
    }
}

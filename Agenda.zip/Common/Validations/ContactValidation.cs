﻿using System;
using System.Text.RegularExpressions;
using Common.Resources;
using Common.CommonErrors;

namespace Common.Validations
{
    public class ContactValidation : Validation
    {
        /// <summary>
        /// Validar nome do contato
        /// </summary>
        /// <param name="name">Nome do contato</param>
        static public void ValidateName(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw ErrorSpam.InvalidName();
        }
        /// <summary>
        /// Validar e-mail do contato
        /// </summary>
        /// <param name="email">E-mail do contato</param>
        static public void ValidateEmail(string email)
        {
            if (!Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
                throw ErrorSpam.InvalidEmail();
        }
        /// <summary>
        /// Validar endereço do contato
        /// </summary>
        /// <param name="address">Endereço do contato</param>
        static public void ValidateAddress(string address)
        {
            if (string.IsNullOrEmpty(address))
                throw ErrorSpam.InvalidAddress();
        }
        /// <summary>
        /// Validar telefone do contato
        /// </summary>
        /// <param name="phone">Telefone do contato</param>
        static public string ValidatePhone(string phone)
        {
            int numSize = 11;
            if (string.IsNullOrEmpty(phone) || (StringExceedsOrLeft(RemoveNonNumeric(phone), 1, numSize)))
                throw ErrorSpam.InvalidPhone();
            return phone.PadLeft(numSize, '0');
        }
        /// <summary>
        /// Validar CEP do contato
        /// </summary>
        /// <param name="zip">CEP do contato</param>
        static public void ValidateZIP(int zip)
        {
            if (zip.ToString().Length != 8)
                throw ErrorSpam.InvalidZIP();
        }
    }
}

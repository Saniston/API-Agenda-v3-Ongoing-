﻿using System;
using System.Collections.Generic;
using System.Text;
using Common.Resources;

namespace Common.CommonErrors
{
    public class ErrorSpam
    {
        public static Exception InvalidAddress()
        {
            return new Exception(Errors.InvalidAddress);
        }
        public static Exception InvalidName()
        {
            return new Exception(Errors.InvalidName);
        }
        public static Exception InvalidPhone()
        {
            return new Exception(Errors.InvalidPhone);
        }
        public static Exception InvalidEmail()
        {
            return new Exception(Errors.InvalidEmail);
        }
        public static Exception NotFound()
        {
            return new Exception(Errors.NotFound);
        }
        public static Exception CannotSave()
        {
            return new Exception(Errors.CannotSave);
        }
        public static Exception InvalidZIP()
        {
            return new Exception(Errors.InvalidZIP);
        }
    }
}

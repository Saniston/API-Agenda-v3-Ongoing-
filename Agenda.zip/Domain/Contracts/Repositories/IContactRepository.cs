﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Contracts.Repositories
{
    public interface IContactRepository : IDisposable
    {
        Contact Get(string name);
        Contact Get(int id);
        IEnumerable<Contact> GetAllContacts();
        void Create(string name, string email, string address, string phone);
        void Update(Contact contact);
        void Delete(string name);
    }
}

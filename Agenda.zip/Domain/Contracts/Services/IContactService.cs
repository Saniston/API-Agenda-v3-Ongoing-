﻿using Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Contracts.Services
{
    public interface IContactService : IDisposable
    {
        Contact GetByName(string name);
        List<Contact> GetAll();
        void SaveContact(string name, string email, string address, string phone);
        void DeleteContact(string name);
    }
}

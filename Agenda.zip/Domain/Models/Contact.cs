﻿using Common.Validations;
using Domain.Resources;
using System;

namespace Domain.Models
{
    public class Contact
    {

        #region Properties
        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Email { get; private set; }
        public string Address { get; private set; }
        public string Phone { get; private set; }
        #pragma warning disable
        private bool isInvalid;
        #pragma warning restore
        #endregion

        #region Constructors
        public Contact(string name, string email, string address, string phone)
        {
            try
            {
                isInvalid = false;
                ContactValidation.ValidateName(name);
                ContactValidation.ValidateEmail(email);
                ContactValidation.ValidateAddress(address);
                Phone = ContactValidation.ValidatePhone(phone);
                Name = name;
                Email = email;
                Address = address;
            }
            catch (Exception ex)
            {
                isInvalid = true;
                Console.WriteLine(ex.Message);
            }
            
        }

        protected Contact() { }
        #endregion

        #region Methods
        public void Validate()
        {
            if (isInvalid)
                throw new Exception(Errors.InvalidContact);
        }
        #endregion

    }
}